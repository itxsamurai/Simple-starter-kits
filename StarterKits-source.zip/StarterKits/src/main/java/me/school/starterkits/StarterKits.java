package me.school.starterkits;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class StarterKits extends JavaPlugin implements Listener, TabExecutor {

    private static final int MACE_SLOT = 11;
    private static final int SPEAR_SLOT = 15;

    private File dataFile;
    private YamlConfiguration data;

    /** Marker holder so we can recognise our GUI. */
    private static class KitMenu implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        Bukkit.getPluginManager().registerEvents(this, this);
        getCommand("setkit").setExecutor(this);
        getCommand("setkit").setTabCompleter(this);
        getCommand("kit").setExecutor(this);
    }

    // ------------------------------------------------------------------ data

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Could not save data.yml: " + e.getMessage());
        }
    }

    private boolean isPending(UUID id) {
        return data.getStringList("pending").contains(id.toString());
    }

    private void setPending(UUID id, boolean pending) {
        List<String> list = new ArrayList<>(data.getStringList("pending"));
        list.remove(id.toString());
        if (pending) list.add(id.toString());
        data.set("pending", list);
        saveData();
    }

    private void saveKit(String type, Player player) {
        List<ItemStack> list = new ArrayList<>(Arrays.asList(player.getInventory().getContents()));
        data.set("kits." + type, list);
        saveData();
    }

    private ItemStack[] loadKit(String type) {
        List<?> raw = data.getList("kits." + type);
        if (raw == null) return null;
        ItemStack[] items = new ItemStack[raw.size()];
        for (int i = 0; i < raw.size(); i++) {
            items[i] = raw.get(i) instanceof ItemStack s ? s : null;
        }
        return items;
    }

    private void giveKit(Player player, ItemStack[] kit) {
        PlayerInventory inv = player.getInventory();
        ItemStack[] copy = new ItemStack[inv.getSize()];
        for (int i = 0; i < copy.length && i < kit.length; i++) {
            copy[i] = kit[i] == null ? null : kit[i].clone();
        }
        inv.clear();
        inv.setContents(copy);
    }

    // ------------------------------------------------------------------- GUI

    private ItemStack named(Material mat, Component name, Component... lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (Component c : lore) l.add(c.decoration(TextDecoration.ITALIC, false));
            meta.lore(l);
        }
        item.setItemMeta(meta);
        return item;
    }

    private void openMenu(Player player) {
        KitMenu holder = new KitMenu();
        Inventory inv = Bukkit.createInventory(holder, 27,
                Component.text("Choose Your Kit", NamedTextColor.DARK_GRAY, TextDecoration.BOLD));
        holder.inventory = inv;

        ItemStack filler = named(Material.BLACK_STAINED_GLASS_PANE, Component.text(" "));
        ItemStack border = named(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "));
        for (int i = 0; i < 27; i++) {
            boolean edge = i < 9 || i >= 18 || i % 9 == 0 || i % 9 == 8;
            inv.setItem(i, edge ? border : filler);
        }

        Material spearMat = Material.matchMaterial("NETHERITE_SPEAR");
        if (spearMat == null) spearMat = Material.TRIDENT;

        inv.setItem(MACE_SLOT, named(Material.MACE,
                Component.text("Mace Kit", NamedTextColor.RED, TextDecoration.BOLD),
                Component.text("Smash your enemies from above.", NamedTextColor.GRAY),
                Component.empty(),
                Component.text("Click to select!", NamedTextColor.GREEN)));

        inv.setItem(SPEAR_SLOT, named(spearMat,
                Component.text("Spear Kit", NamedTextColor.AQUA, TextDecoration.BOLD),
                Component.text("Keep your distance and poke.", NamedTextColor.GRAY),
                Component.empty(),
                Component.text("Click to select!", NamedTextColor.GREEN)));

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof KitMenu)) return;
        e.setCancelled(true);

        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (e.getClickedInventory() != e.getInventory()) return;

        String type = switch (e.getRawSlot()) {
            case MACE_SLOT -> "mace";
            case SPEAR_SLOT -> "spear";
            default -> null;
        };
        if (type == null) return;

        ItemStack[] kit = loadKit(type);
        if (kit == null) {
            player.sendMessage(Component.text("The " + type + " kit hasn't been set up yet. Ask an admin!",
                    NamedTextColor.RED));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        setPending(player.getUniqueId(), false);
        player.closeInventory();
        giveKit(player, kit);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        player.sendMessage(Component.text("You received the " + type + " kit. Good luck!",
                NamedTextColor.GREEN));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof KitMenu) e.setCancelled(true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();
        if (!player.hasPlayedBefore()) {
            setPending(player.getUniqueId(), true);
        }
        if (isPending(player.getUniqueId())) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline() && isPending(player.getUniqueId())) openMenu(player);
            }, 20L);
        }
    }

    // -------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("kit")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Players only.");
                return true;
            }
            if (!isPending(player.getUniqueId())) {
                player.sendMessage(Component.text("You've already chosen your kit.", NamedTextColor.RED));
                return true;
            }
            openMenu(player);
            return true;
        }

        // /setkit
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (!player.isOp()) {
            player.sendMessage(Component.text("Only operators can use this command.", NamedTextColor.RED));
            return true;
        }
        if (args.length != 1 || !(args[0].equalsIgnoreCase("mace") || args[0].equalsIgnoreCase("spear"))) {
            player.sendMessage(Component.text("Usage: /setkit <mace|spear>", NamedTextColor.RED));
            return true;
        }

        String type = args[0].toLowerCase();
        saveKit(type, player);
        player.sendMessage(Component.text("Your current inventory is now the " + type + " kit.",
                NamedTextColor.GREEN));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (cmd.getName().equalsIgnoreCase("setkit") && args.length == 1) {
            return List.of("mace", "spear");
        }
        return List.of();
    }
}
