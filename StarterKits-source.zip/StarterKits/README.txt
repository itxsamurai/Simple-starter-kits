Build:   mvn clean package        (needs JDK 21 + Maven)
Output:  target/StarterKits.jar   -> put in your server's /plugins folder

Usage:
  /setkit mace   - (op) saves YOUR current inventory (items, armor, offhand) as the mace kit
  /setkit spear  - (op) same for the spear kit
  /kit           - re-opens the menu if a new player closed it without choosing

New players (first join only) get the menu automatically. Until they pick, it
re-opens each time they join or run /kit. Kits are stored in plugins/StarterKits/data.yml
